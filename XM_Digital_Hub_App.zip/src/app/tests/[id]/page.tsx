import TestHeader from '@/components/Tests/TestHeader';
import VariantCompare from '@/components/Tests/VariantCompare';
import InlineEditor from '@/components/Tests/InlineEditor';
import AISuggestionBar from '@/components/Tests/AISuggestionBar';
import RerunControls from '@/components/Tests/RerunControls';
import XAIExplanation from '@/components/Tests/XAIExplanation';

export default function TestPage() {
  return (
    <div className="p-8 space-y-6 bg-gray-50 min-h-screen">
      <TestHeader />
      <VariantCompare />
      <AISuggestionBar />
      <InlineEditor />
      <XAIExplanation />
      <RerunControls />
    </div>
  );
}
