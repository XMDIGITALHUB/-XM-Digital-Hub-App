import StatDelta from '@/components/WeeklyReport/StatDelta';
import TopTestCard from '@/components/WeeklyReport/TopTestCard';
import AIWeeklySuggestions from '@/components/WeeklyReport/AIWeeklySuggestions';
import PDFExportButton from '@/components/WeeklyReport/PDFExportButton';

export default function WeeklyReport() {
  return (
    <div className="p-8 space-y-6 bg-gray-50 min-h-screen">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Weekly Snapshot</h1>
        <PDFExportButton />
      </div>
      <StatDelta />
      <TopTestCard />
      <AIWeeklySuggestions />
    </div>
  );
}
