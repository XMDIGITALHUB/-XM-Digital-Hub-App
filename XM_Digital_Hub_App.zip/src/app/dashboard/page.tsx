import InsightHeader from '@/components/Dashboard/InsightHeader';
import SummaryStats from '@/components/Dashboard/SummaryStats';
import SmartSuggestions from '@/components/Dashboard/SmartSuggestions';
import TestOverviewCards from '@/components/Dashboard/TestOverviewCards';

export default function Dashboard() {
  return (
    <div className="p-8 space-y-8 bg-gray-50 min-h-screen">
      <InsightHeader />
      <SummaryStats />
      <SmartSuggestions />
      <TestOverviewCards />
    </div>
  );
}
