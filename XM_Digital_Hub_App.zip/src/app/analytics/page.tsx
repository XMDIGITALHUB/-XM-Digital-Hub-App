import AnalyticsFilterBar from '@/components/Analytics/AnalyticsFilterBar';
import ScrollmapViewer from '@/components/Analytics/ScrollmapViewer';
import ClickmapViewer from '@/components/Analytics/ClickmapViewer';
import SessionList from '@/components/Analytics/SessionList';
import SessionReplayModal from '@/components/Analytics/SessionReplayModal';
import SurveyFeedback from '@/components/Analytics/SurveyFeedback';
import SegmentStats from '@/components/Analytics/SegmentStats';

export default function Analytics() {
  return (
    <div className="p-8 space-y-6 bg-gray-50 min-h-screen">
      <AnalyticsFilterBar />
      <ScrollmapViewer />
      <ClickmapViewer />
      <SessionList />
      <SessionReplayModal />
      <SurveyFeedback />
      <SegmentStats />
    </div>
  );
}
