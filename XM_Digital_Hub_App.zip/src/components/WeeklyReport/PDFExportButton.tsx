export default function PDFExportButton() {
  return (
    <button className="bg-blue-600 text-white px-4 py-2 rounded text-sm">
      Export PDF
    </button>
  );
}
